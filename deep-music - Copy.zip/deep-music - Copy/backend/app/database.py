from motor.motor_asyncio import AsyncIOMotorClient
from app.config import settings

client = AsyncIOMotorClient(settings.mongo_uri)
db = client[settings.db_name]

async def init_indexes():
    await db.users.create_index("email", unique=True)
    await db.songs.create_index([("title", "text"), ("genre", "text")])
    await db.history.create_index("user_id")
    await db.uploads.create_index([("user_id", 1), ("created_at", -1)])
    await db.playlists.create_index([("user_id", 1), ("updated_at", -1)])
