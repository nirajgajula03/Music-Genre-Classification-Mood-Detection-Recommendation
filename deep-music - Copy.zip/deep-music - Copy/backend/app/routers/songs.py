from fastapi import APIRouter, Query
from app.database import db
from app.data.sample_songs import CATALOG

router = APIRouter()

@router.get("")
async def list_songs(q: str = Query(None), genre: str = Query(None), mood: str = Query(None)):
    songs = []
    async for s in db.songs.find({}):
        s["_id"] = str(s["_id"])
        songs.append(s)
    if not songs:
        await db.songs.insert_many(CATALOG)
        songs = [{**s, "_id": str(s.get("_id",""))} for s in CATALOG]
    if q:     songs = [s for s in songs if q.lower() in s["title"].lower() or q.lower() in s.get("artist","").lower()]
    if genre: songs = [s for s in songs if s.get("genre") == genre]
    if mood:  songs = [s for s in songs if s.get("mood") == mood]
    return {"songs": songs}
