from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import StreamingResponse, RedirectResponse
from bson import ObjectId
from app.database import db
from app.routers.playlist import get_user
from app.storage.factory import storage

router = APIRouter()

@router.get("")
async def list_uploads(user=Depends(get_user)):
    docs = []
    async for u in db.uploads.find({"user_id": str(user["_id"])}).sort("created_at", -1):
        u["_id"] = str(u["_id"])
        if u.get("storage_backend") == "s3":
            new_url = storage.public_url(u["storage_id"])
            if new_url != u.get("url"):
                u["url"] = new_url
                await db.uploads.update_one({"_id": ObjectId(u["_id"])}, {"$set": {"url": new_url}})
        docs.append(u)
    return {"uploads": docs}

@router.get("/{upload_id}/stream")
async def stream_upload(upload_id: str):
    try: oid = ObjectId(upload_id)
    except: raise HTTPException(400, "Invalid id")
    doc = await db.uploads.find_one({"_id": oid})
    if not doc: raise HTTPException(404, "Upload not found")
    if doc["storage_backend"] == "s3":
        return RedirectResponse(storage.public_url(doc["storage_id"]))
    stream, ctype = await storage.open_stream(doc["storage_id"])
    async def gen():
        while True:
            chunk = await stream.read(1024 * 1024)
            if not chunk: break
            yield chunk
    return StreamingResponse(gen(), media_type=ctype)

@router.delete("/{upload_id}")
async def delete_upload(upload_id: str, user=Depends(get_user)):
    try: oid = ObjectId(upload_id)
    except: raise HTTPException(400, "Invalid id")
    doc = await db.uploads.find_one({"_id": oid})
    if not doc or doc["user_id"] != str(user["_id"]):
        raise HTTPException(404, "Upload not found")
    try: await storage.delete(doc["storage_id"])
    except Exception as e: print(f"[uploads] storage delete failed: {e}")
    await db.uploads.delete_one({"_id": oid})
    return {"ok": True}
