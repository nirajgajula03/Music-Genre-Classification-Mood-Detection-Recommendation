import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { Sparkles, ArrowRight } from "lucide-react";
import client from "../api/client";
import SongCard from "../components/SongCard";
import Visualizer from "../components/Visualizer";

const GENRES = ["pop","rock","classical","jazz","hiphop","metal","country","disco","reggae","blues","bollywood"];

export default function Home() {
  const [songs, setSongs] = useState([]);
  useEffect(() => { client.get("/songs").then(r => setSongs(r.data.songs)).catch(() => setSongs([])); }, []);
  return (
    <div className="max-w-7xl mx-auto px-4 py-10">
      <section className="glass p-10 md:p-16 relative overflow-hidden">
        <div className="absolute -top-20 -right-20 w-72 h-72 bg-brand/30 rounded-full blur-3xl"/>
        <div className="absolute -bottom-20 -left-20 w-72 h-72 bg-cyan/20 rounded-full blur-3xl"/>
        <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 text-xs"><Sparkles size={14}/> AI-powered music intelligence</span>
        <h1 className="mt-4 font-display text-4xl md:text-6xl font-extrabold leading-tight">Deep Learning Music<br/><span className="bg-gradient-to-r from-brand to-cyan bg-clip-text text-transparent">Classification · Mood · Recommendations</span></h1>
        <p className="mt-4 max-w-2xl text-slate-300">Upload any track and let a deep CNN classify its genre, detect its emotional mood, and surface songs that match the vibe — all in one premium streaming experience.</p>
        <div className="mt-6 flex gap-3">
          <Link to="/upload" className="btn-primary">Get Started <ArrowRight size={16}/></Link>
          <Link to="/about" className="px-5 py-2.5 rounded-xl border border-white/10 hover:bg-white/5">Learn more</Link>
        </div>
        <div className="mt-8"><Visualizer/></div>
      </section>
      <section className="mt-10"><div className="font-display text-2xl font-bold mb-4">Featured music</div><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">{songs.slice(0,5).map(s => <SongCard key={s.title} song={s}/>)}</div></section>
      <section className="mt-10"><div className="font-display text-2xl font-bold mb-4">Popular genres</div><div className="grid grid-cols-2 md:grid-cols-5 gap-3">{GENRES.map(g => <Link key={g} to={`/recommend?genre=${g}`} className="card capitalize text-center font-medium hover:scale-[1.02]">{g}</Link>)}</div></section>
      <section className="mt-10"><div className="font-display text-2xl font-bold mb-4">Recently played</div><div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">{songs.slice(5,10).map(s => <SongCard key={s.title} song={s}/>)}</div></section>
    </div>
  );
}
