
import { createContext, useContext, useRef, useState, useEffect } from "react";
import { resolveStreamUrl } from "../api/client";
import client from "../api/client";

const PlayerContext = createContext(null);
export const usePlayer = () => useContext(PlayerContext);

export function PlayerProvider({ children }) {
  const audioRef = useRef(null);
  const nextRef = useRef(() => {});

  const [queue, setQueue] = useState([]);
  const [index, setIndex] = useState(0);
  const [playing, setPlaying] = useState(false);
  const [volume, setVolume] = useState(0.8);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [playSession, setPlaySession] = useState(0);
  const [error, setError] = useState("");

  const current = queue[index] || null;

  const playQueue = (list, i = 0) => {
    if (!list?.length) return;
    setQueue(list);
    setIndex(Math.max(0, Math.min(i, list.length - 1)));
    setProgress(0);
    setDuration(0);
    setError("");
    setPlaying(true);
    setPlaySession(s => s + 1);
  };

  const toggle = () => {
    if (current) setPlaying(p => !p);
  };

  nextRef.current = () => {
    setIndex(i => Math.min(i + 1, queue.length - 1));
  };

  const next = () => {
    if (index < queue.length - 1) {
      setIndex(i => i + 1);
    } else {
      setPlaying(false);
    }
  };

  const prev = () => {
    setIndex(i => Math.max(i - 1, 0));
  };

  const seek = (t) => {
    const a = audioRef.current;
    if (!a || !Number.isFinite(a.duration) || a.duration <= 0) return;

    const target = Math.max(0, Math.min(Number(t), a.duration));
    a.currentTime = target;
    setProgress(target);
  };

  const setVol = (v) => {
    const safeVolume = Math.max(0, Math.min(1, v));
    setVolume(safeVolume);
    if (audioRef.current) audioRef.current.volume = safeVolume;
  };

  useEffect(() => {
    const a = audioRef.current;
    if (!a || !current) return;

    a.pause();
    a.src = resolveStreamUrl(current.url);
    a.load();
    a.volume = volume;

    setProgress(0);
    setDuration(0);
    setError("");

    if (playing) {
      a.play().catch(() => {
        setPlaying(false);
        setError("Unable to play this song.");
      });
    }
  }, [current, playing]);

  useEffect(() => {
    const a = audioRef.current;
    if (!a) return;

    const onTime = () => {
      setProgress(a.currentTime || 0);
    };

    const onDuration = () => {
      setDuration(Number.isFinite(a.duration) ? a.duration : 0);
    };

    const onEnd = () => nextRef.current();

    const onError = () => {
      setError("Unable to load this song.");
      setPlaying(false);
    };

    a.addEventListener("timeupdate", onTime);
    a.addEventListener("loadedmetadata", onDuration);
    a.addEventListener("durationchange", onDuration);
    a.addEventListener("ended", onEnd);
    a.addEventListener("error", onError);

    return () => {
      a.removeEventListener("timeupdate", onTime);
      a.removeEventListener("loadedmetadata", onDuration);
      a.removeEventListener("durationchange", onDuration);
      a.removeEventListener("ended", onEnd);
      a.removeEventListener("error", onError);
    };
  }, []);

  useEffect(() => {
    if (!current || !localStorage.getItem("dm_token")) return;

    client.post("/playlist/history", {
      song_id: current._id || current.song_id || current.title,
      title: current.title,
      artist: current.artist || "",
      cover: current.cover || "",
      genre: current.genre || "",
    }).catch(() => {});
  }, [playSession]);

  useEffect(() => {
    const onKey = (e) => {
      const tag = e.target.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA" || e.target.isContentEditable) return;
      if (!current) return;

      if (e.code === "Space") {
        e.preventDefault();
        setPlaying(p => !p);
      } else if (e.code === "ArrowRight") {
        e.preventDefault();
        setIndex(i => Math.min(i + 1, queue.length - 1));
      } else if (e.code === "ArrowLeft") {
        e.preventDefault();
        setIndex(i => Math.max(i - 1, 0));
      }
    };

    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [current, queue.length]);

  return (
    <PlayerContext.Provider value={{
      current, queue, index, playing, progress, duration, volume, error,
      playQueue, toggle, next, prev, seek, setVolume: setVol
    }}>
      {children}
      <audio ref={audioRef} preload="metadata" />
    </PlayerContext.Provider>
  );
}
