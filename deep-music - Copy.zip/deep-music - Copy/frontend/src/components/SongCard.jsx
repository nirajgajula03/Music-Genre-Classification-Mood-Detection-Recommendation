
import { Play, Plus, Heart } from "lucide-react";
import { useState } from "react";
import { usePlayer } from "../context/PlayerContext";
import { useToast } from "../context/ToastContext";
import client from "../api/client";
import AddToPlaylistModal from "./AddToPlaylistModal";

export default function SongCard({ song }) {
  const p = usePlayer();
  const { toast } = useToast();
  const [showModal, setShowModal] = useState(false);
  const [fav, setFav] = useState(false);
  const [imageSrc, setImageSrc] = useState(
    song.cover || "/music-cover.svg"
  );

  const favToggle = async () => {
    if (!localStorage.getItem("dm_token")) {
      toast("Login to save favourites", "warning");
      return;
    }

    try {
      await client.post("/playlist/favourites", {
        song_id: song._id || song.title,
        title: song.title,
        artist: song.artist || "",
        cover: song.cover || "",
        genre: song.genre || ""
      });
      setFav(true);
      toast("Added to favourites", "success");
    } catch {
      toast("Could not save favourite", "error");
    }
  };

  return (
    <div className="card group">
      <div className="relative">
        <img
          src={imageSrc}
          onError={() => setImageSrc("/music-cover.svg")}
          alt={song.title || "Music cover"}
          className="w-full aspect-square object-cover rounded-xl"
        />

        <div className="absolute bottom-2 right-2 flex gap-2">
          <button
            onClick={() => p.playQueue([song])}
            className="p-3 rounded-full bg-gradient-to-br from-brand to-cyan opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition"
          >
            <Play size={16}/>
          </button>

          <button
            onClick={() => setShowModal(true)}
            className="p-3 rounded-full bg-white/10 backdrop-blur opacity-0 group-hover:opacity-100 translate-y-2 group-hover:translate-y-0 transition"
          >
            <Plus size={16}/>
          </button>
        </div>
      </div>

      <div className="mt-3">
        <div className="font-medium truncate">{song.title}</div>
        <div className="text-xs text-slate-400 truncate">
          {song.artist}
        </div>

        <div className="mt-2 flex items-center justify-between text-xs">
          <span className="px-2 py-1 rounded bg-white/5 capitalize">
            {song.genre}
          </span>

          <button
            onClick={favToggle}
            className={`p-1.5 rounded-full hover:bg-white/10 ${
              fav ? "text-pink-400" : "text-slate-400"
            }`}
          >
            <Heart size={14}/>
          </button>
        </div>
      </div>

      {showModal && (
        <AddToPlaylistModal
          song={song}
          onClose={() => setShowModal(false)}
        />
      )}
    </div>
  );
}
