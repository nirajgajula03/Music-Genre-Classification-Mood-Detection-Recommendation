import { usePlayer } from "../context/PlayerContext";
import { Play, Pause, SkipBack, SkipForward, Volume2, Heart } from "lucide-react";
import { useState } from "react";
import client from "../api/client";
import { useToast } from "../context/ToastContext";
import Visualizer from "./Visualizer";

const fmt = (s) => s ? `${Math.floor(s/60)}:${String(Math.floor(s%60)).padStart(2,"0")}` : "0:00";

export default function MusicPlayer() {
  const p = usePlayer();
  const { toast } = useToast();
  const [fav, setFav] = useState(false);
  if (!p.current) return null;
  const favToggle = async () => {
    if (!localStorage.getItem("dm_token")) { toast("Login to save favourites", "warning"); return; }
    try {
      await client.post("/playlist/favourites", { song_id: p.current._id || p.current.title, title: p.current.title, artist: p.current.artist, cover: p.current.cover, genre: p.current.genre });
      setFav(true); toast("Added to favourites", "success");
    } catch { toast("Could not save favourite", "error"); }
  };
  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 glass !rounded-none !border-x-0 !border-b-0">
      <Visualizer active={p.playing}/>
      <div className="max-w-7xl mx-auto px-3 py-2 flex items-center gap-3">
        <img src={p.current.cover} alt="" className="w-10 h-10 sm:w-12 sm:h-12 rounded-lg object-cover shrink-0"/>
        <div className="min-w-0 flex-1">
          <div className="truncate text-sm font-medium">{p.current.title}</div>
          <div className="truncate text-xs text-slate-400">{p.current.artist}</div>
        </div>
        <div className="flex items-center gap-1 sm:gap-2 shrink-0">
          <button onClick={p.prev} className="p-1.5 sm:p-2 hover:bg-white/10 rounded-full hidden sm:block"><SkipBack size={16}/></button>
          <button onClick={p.toggle} className="p-2.5 sm:p-3 rounded-full bg-gradient-to-br from-brand to-cyan">{p.playing ? <Pause size={16}/> : <Play size={16}/>}</button>
          <button onClick={p.next} className="p-1.5 sm:p-2 hover:bg-white/10 rounded-full hidden sm:block"><SkipForward size={16}/></button>
        </div>
        <div className="hidden md:flex items-center gap-2 w-48 lg:w-72">
          <span className="text-xs text-slate-400 w-10 text-right">{fmt(p.progress)}</span>
          <input type="range" min={0} max={p.duration || 0} value={p.progress} onChange={(e) => p.seek(+e.target.value)} className="flex-1 accent-cyan"/>
          <span className="text-xs text-slate-400 w-10">{fmt(p.duration)}</span>
        </div>
        <div className="hidden lg:flex items-center gap-2 shrink-0">
          <Volume2 size={16}/>
          <input type="range" min={0} max={1} step={0.01} value={p.volume} onChange={(e) => p.setVolume(+e.target.value)} className="w-24 accent-cyan"/>
        </div>
        <button onClick={favToggle} className={`p-1.5 sm:p-2 rounded-full shrink-0 ${fav ? "text-pink-400" : "hover:bg-white/10"}`}><Heart size={16}/></button>
      </div>
      <div className="md:hidden px-3 pb-1 flex items-center gap-2">
        <span className="text-[10px] text-slate-400 w-8">{fmt(p.progress)}</span>
        <input type="range" min={0} max={p.duration || 0} value={p.progress} onChange={(e) => p.seek(+e.target.value)} className="flex-1 accent-cyan h-1"/>
        <span className="text-[10px] text-slate-400 w-8 text-right">{fmt(p.duration)}</span>
      </div>
    </div>
  );
}
